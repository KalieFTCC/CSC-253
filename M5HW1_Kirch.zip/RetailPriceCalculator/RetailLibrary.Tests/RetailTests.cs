﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailLibrary;
using Xunit;

namespace RetailLibrary.Tests
{
    public class RetailTests
    {
        [Fact]
        public void ShouldMultiply()
        {
            //arrange 
            double expected = 7.50;

            //act
            double actual = Retail.CalculateRetail(5, 50);

            //assert
            Assert.Equal(expected, actual);
        }
        [Theory]
        [InlineData(1000, 11, 1110)]
        [InlineData(27.5, 50, 41.25)]
        public void ThoeryMultiply(double x, double y, double result)
        {
            //act
            double actual = Retail.CalculateRetail(x, y);

            //assert
            Assert.Equal(result, actual);

        }
    }
}
