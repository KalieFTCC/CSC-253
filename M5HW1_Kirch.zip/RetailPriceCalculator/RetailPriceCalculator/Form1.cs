﻿using RetailLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RetailPriceCalculator
{

    /*Kalie Kirch
     *11/13/2022
     *Retail Calculator project that uses a markup percentage to get the final retail price of a product
     *CSC 253
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcPriceButton_Click(object sender, EventArgs e)
        {
            double wholesale;
            double markup;
            if (double.TryParse(wholesaleCostTextBox.Text, out wholesale) && (double.TryParse(markupPercentTextbox.Text, out markup)))
            {
                double retailPrice = Retail.CalculateRetail(wholesale, markup);
                finalPriceTextBox.Text = retailPrice.ToString("C");
            }
            else
                MessageBox.Show("Enter numbers only please", "Invalid Input");
        }
    }
}
