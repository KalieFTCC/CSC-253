﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ListManipulatingLibrary
{
    public class Filtering
    {
        public static List<int> AccessFile() 
        {
            //converts a text file into a string list
            List<int> numbersList = new List<int>();
            using (OpenFileDialog openFileDialog = new OpenFileDialog() { Filter = "Text Documents(*.txt)|*.txt", ValidateNames = true, Multiselect = false })
            {
                while (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string[] lines = System.IO.File.ReadAllLines(openFileDialog.FileName);
                    List<int> numbers = new List<int>();
                    //for each loop populates the list.
                    foreach (string i in lines)
                    {
                        numbersList.Add(Convert.ToInt32(i));
                        //converts string to int
                    }
                    numbers.Sort();
   
                }
                return numbersList;
            }
        }
        public static List<int> RemoveNegative(List<int> numbersList)
        {
            numbersList.RemoveAll(i => i < 0);
            return numbersList;
        }
        public static List<int> DisplayUpToTen(List<int> numberList)
        {
            List<int> modifiedList = numberList.FindAll(n => n >= 1 && n <= 10);
            return modifiedList;
        }

    }
}
