﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ListManipulatingLibrary;

namespace ListManipulators
{
    /**
    * 10/10/2022
    * CSC 253
    * Kalie Kirch
    * Filters a text file ro remove all negative numbers and anything below 10
    */
    public partial class ListForm : Form
    {
        public ListForm()
        {
            InitializeComponent();
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void openFileBtn_Click(object sender, EventArgs e)
        {
            List<int> numberList = Filtering.AccessFile();
            Filtering.RemoveNegative(numberList);
            List<int> displayList = Filtering.DisplayUpToTen(numberList);
            foreach (int number in displayList) 
            {
                numbersListBox.Items.Add(number);
            }
        }
    }
}
