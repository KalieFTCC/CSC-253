﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.IO;

namespace HousingLibrary
{
    public class HousingOperations
    {
        public static List<House> AccessFile() 
        {
            List<House> housesList = new List<House>();
            using (OpenFileDialog openFileDialog = new OpenFileDialog() { Filter = "Comma Seperate Value(*.csv)|*.csv", ValidateNames = true, Multiselect = false })
            {

                while (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string[] lines = System.IO.File.ReadAllLines(openFileDialog.FileName); ;

                    for (int i = 0; i < lines.Length; i++)
                    {
                        //The lines create new house objects, and the house objects filters the data type. I heard this was best practice
                        House houses = new House(lines[i]);
                        housesList.Add(houses);
                    }
                }
                return housesList;
            }
        }
        public static List<House> RangeSearchDisplayPrice(decimal low, decimal high, List<House> houseList)
        {
            List<House> searchedHousesList = houseList.FindAll(a => a.Price >= low && a.Price <= high);
            return searchedHousesList;
        }

        public static List<House> RangeSearchDisplayBedroom(double low, double high, List<House> houseList)
        {
            List<House> searchedHousesList = houseList.FindAll(a => a.Bed >= low && a.Bed <= high);
            return searchedHousesList;
        }

        public static List<House> RangeSearchDisplayBathroom(double low, double high, List<House> houseList)
        {
            List<House> searchedHousesList = houseList.FindAll(a => a.Bath >= low && a.Bath <= high);
            return searchedHousesList;
        }

        public static List<House> RangeSearchDisplaySqFt(double low, double high, List<House> houseList)
        {
            List<House> searchedHousesList = houseList.FindAll(a => a.Squarefeet >= low && a.Squarefeet <= high);
            return searchedHousesList;
        }
    }
}
