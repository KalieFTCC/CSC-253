﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HousingLibrary
{
    public class House
    {
        //public House(decimal price, double bed, double bath, double squarefeet)
        public House(string rowData)
        {
           string[] data = rowData.Split(',');
           this.Price = Convert.ToDecimal(data[0]);
           this.Bed = Convert.ToDouble(data[1]);
           this.Bath = Convert.ToDouble(data[1]);
           this.Squarefeet = Convert.ToDouble(data[1]);
        }

        public decimal Price { get; set; }
        public double Bed { get; set; }
        public double Bath { get; set; }
        public double Squarefeet { get; set; }

        public override string ToString()
        {
            string houseFormatString = string.Format("{0:C}, ", Price) + string.Format("{0} Bedrooms, ", Bed) +
                string.Format("{0} Baths, ", Bath) + string.Format("{0} Sqft", Squarefeet);
            return houseFormatString;
        }
    }
}
