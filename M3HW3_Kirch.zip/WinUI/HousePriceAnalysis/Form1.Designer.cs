﻿namespace HousePriceAnalysis
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.houseList = new System.Windows.Forms.ListBox();
            this.searchButton = new System.Windows.Forms.Button();
            this.priceHighTxtbox = new System.Windows.Forms.TextBox();
            this.bedHighTxtbox = new System.Windows.Forms.TextBox();
            this.bathHighTxtbox = new System.Windows.Forms.TextBox();
            this.sqftHighTxtbox = new System.Windows.Forms.TextBox();
            this.priceLowTxtbox = new System.Windows.Forms.TextBox();
            this.bedLowTxtbox = new System.Windows.Forms.TextBox();
            this.bathLowTxtbox = new System.Windows.Forms.TextBox();
            this.sqftLowTxtbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // houseList
            // 
            this.houseList.FormattingEnabled = true;
            this.houseList.Location = new System.Drawing.Point(447, 12);
            this.houseList.Name = "houseList";
            this.houseList.Size = new System.Drawing.Size(223, 420);
            this.houseList.TabIndex = 0;
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(175, 353);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(86, 30);
            this.searchButton.TabIndex = 1;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // priceHighTxtbox
            // 
            this.priceHighTxtbox.Location = new System.Drawing.Point(295, 54);
            this.priceHighTxtbox.Name = "priceHighTxtbox";
            this.priceHighTxtbox.Size = new System.Drawing.Size(100, 20);
            this.priceHighTxtbox.TabIndex = 2;
            // 
            // bedHighTxtbox
            // 
            this.bedHighTxtbox.Location = new System.Drawing.Point(295, 119);
            this.bedHighTxtbox.Name = "bedHighTxtbox";
            this.bedHighTxtbox.Size = new System.Drawing.Size(100, 20);
            this.bedHighTxtbox.TabIndex = 3;
            // 
            // bathHighTxtbox
            // 
            this.bathHighTxtbox.Location = new System.Drawing.Point(295, 178);
            this.bathHighTxtbox.Name = "bathHighTxtbox";
            this.bathHighTxtbox.Size = new System.Drawing.Size(100, 20);
            this.bathHighTxtbox.TabIndex = 4;
            // 
            // sqftHighTxtbox
            // 
            this.sqftHighTxtbox.Location = new System.Drawing.Point(295, 240);
            this.sqftHighTxtbox.Name = "sqftHighTxtbox";
            this.sqftHighTxtbox.Size = new System.Drawing.Size(100, 20);
            this.sqftHighTxtbox.TabIndex = 5;
            // 
            // priceLowTxtbox
            // 
            this.priceLowTxtbox.Location = new System.Drawing.Point(115, 54);
            this.priceLowTxtbox.Name = "priceLowTxtbox";
            this.priceLowTxtbox.Size = new System.Drawing.Size(100, 20);
            this.priceLowTxtbox.TabIndex = 6;
            // 
            // bedLowTxtbox
            // 
            this.bedLowTxtbox.Location = new System.Drawing.Point(115, 119);
            this.bedLowTxtbox.Name = "bedLowTxtbox";
            this.bedLowTxtbox.Size = new System.Drawing.Size(100, 20);
            this.bedLowTxtbox.TabIndex = 7;
            // 
            // bathLowTxtbox
            // 
            this.bathLowTxtbox.Location = new System.Drawing.Point(115, 178);
            this.bathLowTxtbox.Name = "bathLowTxtbox";
            this.bathLowTxtbox.Size = new System.Drawing.Size(100, 20);
            this.bathLowTxtbox.TabIndex = 8;
            // 
            // sqftLowTxtbox
            // 
            this.sqftLowTxtbox.Location = new System.Drawing.Point(115, 240);
            this.sqftLowTxtbox.Name = "sqftLowTxtbox";
            this.sqftLowTxtbox.Size = new System.Drawing.Size(100, 20);
            this.sqftLowTxtbox.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Price Range";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Bedrooms";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 178);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Bathroom";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 240);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Square Feet";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.sqftLowTxtbox);
            this.Controls.Add(this.bathLowTxtbox);
            this.Controls.Add(this.bedLowTxtbox);
            this.Controls.Add(this.priceLowTxtbox);
            this.Controls.Add(this.sqftHighTxtbox);
            this.Controls.Add(this.bathHighTxtbox);
            this.Controls.Add(this.bedHighTxtbox);
            this.Controls.Add(this.priceHighTxtbox);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.houseList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox houseList;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.TextBox priceHighTxtbox;
        private System.Windows.Forms.TextBox bedHighTxtbox;
        private System.Windows.Forms.TextBox bathHighTxtbox;
        private System.Windows.Forms.TextBox sqftHighTxtbox;
        private System.Windows.Forms.TextBox priceLowTxtbox;
        private System.Windows.Forms.TextBox bedLowTxtbox;
        private System.Windows.Forms.TextBox bathLowTxtbox;
        private System.Windows.Forms.TextBox sqftLowTxtbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

