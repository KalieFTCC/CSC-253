﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HousingLibrary;


/**
 * 10.20.2022
 * CSC 253
 * Kalie
 * This program helps you filter through available houses for sale to find a desired one according to your personal criteria.
 */



namespace HousePriceAnalysis
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            decimal lowRange;
            decimal highRange;
            List<House> searchedHousesList = HousingOperations.AccessFile();
            if (priceLowTxtbox.TextLength != 0 && priceHighTxtbox.TextLength != 0)
            {
                try
                {
                    lowRange = decimal.Parse(priceLowTxtbox.Text);
                    highRange = decimal.Parse(priceHighTxtbox.Text);
                    searchedHousesList = HousingOperations.RangeSearchDisplayPrice(lowRange, highRange, searchedHousesList);
                }
                catch
                {
                    MessageBox.Show("Please enter an actual number");
                }
            }
            if (bedLowTxtbox.TextLength != 0 && bedHighTxtbox.TextLength != 0)
            {
                try
                {
                    lowRange = decimal.Parse(bedLowTxtbox.Text);
                    highRange = decimal.Parse(bedHighTxtbox.Text);
                    searchedHousesList = HousingOperations.RangeSearchDisplayPrice(lowRange, highRange, searchedHousesList);
                }
                catch
                {
                    MessageBox.Show("Please enter an actual number");
                }
            }
            if (bathLowTxtbox.TextLength != 0 && bathHighTxtbox.TextLength != 0)
            {
                try
                {
                    lowRange = decimal.Parse(bathLowTxtbox.Text);
                    highRange = decimal.Parse(bathHighTxtbox.Text);
                    searchedHousesList = HousingOperations.RangeSearchDisplayPrice(lowRange, highRange, searchedHousesList);
                }
                catch
                {
                    MessageBox.Show("Please enter an actual number");
                }
            }
            if (sqftLowTxtbox.TextLength != 0 && sqftHighTxtbox.TextLength != 0)
            {
                try
                {
                    lowRange = decimal.Parse(sqftLowTxtbox.Text);
                    highRange = decimal.Parse(sqftHighTxtbox.Text);
                    searchedHousesList = HousingOperations.RangeSearchDisplayPrice(lowRange, highRange, searchedHousesList);
                }
                catch
                {
                    MessageBox.Show("Please enter an actual number");
                }
            }
            foreach (var house in searchedHousesList)
            {
                houseList.Items.Add(house.ToString());
            }
        }
    }
}
