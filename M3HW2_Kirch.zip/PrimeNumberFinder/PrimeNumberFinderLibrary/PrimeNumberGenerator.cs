﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeNumberFinderLibrary
{
    public class PrimeNumberGenerator
    {
        public static bool PrimeBool(int input)
        {
            int n = 0;
            for (int i = 1; i <= input; i++)
            {
                if (input % i == 0)
                {
                    n++;
                }
            }
            if (n == 2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static List<int> PrimeNumbers(List<int> numberList)
        {
            List<int> primeNums = new List<int>();
            primeNums = numberList.FindAll(PrimeBool);
            return primeNums;
        }

        public static List<int> PrimeBool(List<int> allOfNums)
        {
            throw new NotImplementedException();
        }
    }
}
