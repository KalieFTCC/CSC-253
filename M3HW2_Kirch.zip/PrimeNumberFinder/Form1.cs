﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using PrimeNumberFinderLibrary;

namespace PrimeNumberFinder
{

    /**
    * 10/14/2022
    * CSC 253
    * Kalie Kirch
    * Filters all numbers below the inputted number to create a list of prime numbers.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void filterButton_Click(object sender, EventArgs e)
        {
            int entered = int.Parse(enteredNumBox.Text);
            List<int> allOfNums = new List<int>();
            List<int> primeNumbers = new List<int>();
            for (int l = 2; l <= entered; l++)
            { 
                primeNumbers.Add(l); 
            }
            if (allOfNums.Count > 1)
            {
                primeNumbers = PrimeNumberGenerator.PrimeBool(allOfNums);
                foreach (int number in primeNumbers)

                {
                    primesList.Items.Add(number);

                }
            }
            else 
            {
                this.primesList.Items.Clear();
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            enteredNumBox.Clear();
            primesList.Items.Clear();
        }
    }
}
