﻿using Analysis_Library;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
* 10/22/2022
* CSC 253
* Kalie Kirch
* This project analyzes two text files and sorts which words are unique or not by certain categories. 
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        List<string> firstFile = new List<string>();
        List<string> secondFile = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }

        private void uniqueButton_Click(object sender, EventArgs e)
        {
            namesListBox.Items.Clear();
            var mergedList = firstFile.Concat(secondFile).ToList();
            List <string> displayList = LinQOperations.UniqueWords(mergedList);
            foreach (string word in displayList) 
            {
                namesListBox.Items.Add(word);
            }
        }

        public void firstListButton_Click(object sender, EventArgs e)
        {
            firstFile = LinQOperations.AccessFile();
        }

        private void secondListButton_Click(object sender, EventArgs e)
        {
            secondFile = LinQOperations.AccessFile();
        }

        private void secondListAllButton_Click(object sender, EventArgs e)
        {
            namesListBox.Items.Clear();
            List<string> displayList = new List<string>();
            foreach (string word in secondFile) 
            {
                // //turns the second file into a new list so it displays all the words in it
                displayList.Add(word);
            }
            foreach (string word in displayList) 
            {
                namesListBox.Items.Add(word);
            }

        }

        private void firstListAllButton_Click(object sender, EventArgs e)
        {
            namesListBox.Items.Clear();
            List<string> displayList = new List<string>();
            foreach (string word in firstFile)
            {
                //turns the first file into a new list so it displays all the words in it
                displayList.Add(word);
            }
            foreach (string word in displayList)
            {
                namesListBox.Items.Add(word);
            }
        }

        private void onlyFirstButton_Click(object sender, EventArgs e)
        {
            namesListBox.Items.Clear();
            //the Except LINQ method here makes it so that all the words that are in the second file will be cut from the new list created in uniqueList
            var uniqueList = firstFile.Except(secondFile).ToList();
            foreach (string word in uniqueList) 
            {
                namesListBox.Items.Add(word);
            }

        }

        private void onlySecondButton_Click(object sender, EventArgs e)
        {
            namesListBox.Items.Clear();
            //same as line 85
            var uniqueList = secondFile.Except(firstFile).ToList();
            foreach (string word in uniqueList)
            {
                namesListBox.Items.Add(word);
            }
        }

        private void eitherButton_Click(object sender, EventArgs e)
        {
            namesListBox.Items.Clear();
            //creates a unique list of words for two different files, then joins the lists together with Concat.
            var uniqueList = firstFile.Except(secondFile).ToList();
            var unique2 = secondFile.Except(firstFile).ToList();
            var mergedUnique = uniqueList.Concat(unique2);
            foreach (string word in mergedUnique) 
            {
                namesListBox.Items.Add(word);
            }
        }

        //TODO Turn these LINQ operations that I am using in these buttons into options Like I did for UniqueWords() in LINQOperations. I did this last minute so I skipped figuring that out 
        //to instead finish in a timely manner, regardless I feel like I understand the material and can easily turn this into an object oriented program. 
    }
}
