﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.namesListBox = new System.Windows.Forms.ListBox();
            this.uniqueButton = new System.Windows.Forms.Button();
            this.firstListButton = new System.Windows.Forms.Button();
            this.secondListAllButton = new System.Windows.Forms.Button();
            this.onlyFirstButton = new System.Windows.Forms.Button();
            this.onlySecondButton = new System.Windows.Forms.Button();
            this.secondListButton = new System.Windows.Forms.Button();
            this.firstListAllButton = new System.Windows.Forms.Button();
            this.eitherButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // namesListBox
            // 
            this.namesListBox.FormattingEnabled = true;
            this.namesListBox.Location = new System.Drawing.Point(251, 24);
            this.namesListBox.Name = "namesListBox";
            this.namesListBox.Size = new System.Drawing.Size(326, 381);
            this.namesListBox.TabIndex = 0;
            // 
            // uniqueButton
            // 
            this.uniqueButton.Location = new System.Drawing.Point(30, 137);
            this.uniqueButton.Name = "uniqueButton";
            this.uniqueButton.Size = new System.Drawing.Size(113, 23);
            this.uniqueButton.TabIndex = 1;
            this.uniqueButton.Text = "Unique Words";
            this.uniqueButton.UseVisualStyleBackColor = true;
            this.uniqueButton.Click += new System.EventHandler(this.uniqueButton_Click);
            // 
            // firstListButton
            // 
            this.firstListButton.Location = new System.Drawing.Point(91, 24);
            this.firstListButton.Name = "firstListButton";
            this.firstListButton.Size = new System.Drawing.Size(114, 23);
            this.firstListButton.TabIndex = 2;
            this.firstListButton.Text = "Load First File";
            this.firstListButton.UseVisualStyleBackColor = true;
            this.firstListButton.Click += new System.EventHandler(this.firstListButton_Click);
            // 
            // secondListAllButton
            // 
            this.secondListAllButton.Location = new System.Drawing.Point(30, 215);
            this.secondListAllButton.Name = "secondListAllButton";
            this.secondListAllButton.Size = new System.Drawing.Size(158, 23);
            this.secondListAllButton.TabIndex = 3;
            this.secondListAllButton.Text = "All words for second file";
            this.secondListAllButton.UseVisualStyleBackColor = true;
            this.secondListAllButton.Click += new System.EventHandler(this.secondListAllButton_Click);
            // 
            // onlyFirstButton
            // 
            this.onlyFirstButton.Location = new System.Drawing.Point(39, 264);
            this.onlyFirstButton.Name = "onlyFirstButton";
            this.onlyFirstButton.Size = new System.Drawing.Size(137, 23);
            this.onlyFirstButton.TabIndex = 4;
            this.onlyFirstButton.Text = "Only appear in First file";
            this.onlyFirstButton.UseVisualStyleBackColor = true;
            this.onlyFirstButton.Click += new System.EventHandler(this.onlyFirstButton_Click);
            // 
            // onlySecondButton
            // 
            this.onlySecondButton.Location = new System.Drawing.Point(42, 313);
            this.onlySecondButton.Name = "onlySecondButton";
            this.onlySecondButton.Size = new System.Drawing.Size(163, 23);
            this.onlySecondButton.TabIndex = 5;
            this.onlySecondButton.Text = "Only appears in Second file";
            this.onlySecondButton.UseVisualStyleBackColor = true;
            this.onlySecondButton.Click += new System.EventHandler(this.onlySecondButton_Click);
            // 
            // secondListButton
            // 
            this.secondListButton.Location = new System.Drawing.Point(91, 68);
            this.secondListButton.Name = "secondListButton";
            this.secondListButton.Size = new System.Drawing.Size(114, 23);
            this.secondListButton.TabIndex = 6;
            this.secondListButton.Text = "Load Second File";
            this.secondListButton.UseVisualStyleBackColor = true;
            this.secondListButton.Click += new System.EventHandler(this.secondListButton_Click);
            // 
            // firstListAllButton
            // 
            this.firstListAllButton.Location = new System.Drawing.Point(30, 175);
            this.firstListAllButton.Name = "firstListAllButton";
            this.firstListAllButton.Size = new System.Drawing.Size(158, 23);
            this.firstListAllButton.TabIndex = 7;
            this.firstListAllButton.Text = "All words for first file";
            this.firstListAllButton.UseVisualStyleBackColor = true;
            this.firstListAllButton.Click += new System.EventHandler(this.firstListAllButton_Click);
            // 
            // eitherButton
            // 
            this.eitherButton.Location = new System.Drawing.Point(42, 362);
            this.eitherButton.Name = "eitherButton";
            this.eitherButton.Size = new System.Drawing.Size(163, 23);
            this.eitherButton.TabIndex = 8;
            this.eitherButton.Text = "Appear in either but not both";
            this.eitherButton.UseVisualStyleBackColor = true;
            this.eitherButton.Click += new System.EventHandler(this.eitherButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(618, 450);
            this.Controls.Add(this.eitherButton);
            this.Controls.Add(this.firstListAllButton);
            this.Controls.Add(this.secondListButton);
            this.Controls.Add(this.onlySecondButton);
            this.Controls.Add(this.onlyFirstButton);
            this.Controls.Add(this.secondListAllButton);
            this.Controls.Add(this.firstListButton);
            this.Controls.Add(this.uniqueButton);
            this.Controls.Add(this.namesListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox namesListBox;
        private System.Windows.Forms.Button uniqueButton;
        private System.Windows.Forms.Button firstListButton;
        private System.Windows.Forms.Button secondListAllButton;
        private System.Windows.Forms.Button onlyFirstButton;
        private System.Windows.Forms.Button onlySecondButton;
        private System.Windows.Forms.Button secondListButton;
        private System.Windows.Forms.Button firstListAllButton;
        private System.Windows.Forms.Button eitherButton;
    }
}

