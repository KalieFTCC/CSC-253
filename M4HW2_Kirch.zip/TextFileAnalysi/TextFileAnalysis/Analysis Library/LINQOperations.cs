﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Analysis_Library
{
    public class LinQOperations
    {
        public static List<string> AccessFile()
        {
            //converts a text file into a string list
            List<string> wordsList = new List<string>();
            using (OpenFileDialog openFileDialog = new OpenFileDialog() { Filter = "Text Documents(*.txt)|*.txt", ValidateNames = true, Multiselect = false })
            {
                while (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string[] lines = System.IO.File.ReadAllLines(openFileDialog.FileName);
                    
                    //for each loop populates the list.
                    foreach (string i in lines)
                    {
                        wordsList.Add(i);
                        
                    }
                    wordsList.Sort();

                }
                return wordsList;
            }
        }
        public static List<string> UniqueWords(List<string> wordsList) 
        {
            List<string> modifiedList = new List<string>();
            foreach (string word in wordsList.Distinct()) 
            {
                modifiedList.Add(word);
            }
            return modifiedList;
        }
        
    }
}
