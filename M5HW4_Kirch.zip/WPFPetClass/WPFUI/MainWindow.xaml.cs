﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PetLibrary;

namespace WPFUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 


    /*
     * Kalie Kirch
     * 11/26/2022
     * Creates a list of pets from user input, sorting data into a pet class
     */
    public partial class MainWindow : Window
    {
        List<Pet> pets = new List<Pet>();
        int petAge;
        public MainWindow()
        {
            InitializeComponent();
        }
        public bool ValidInput()
        {
            //this makes sure the input inside the textbox is correct
            bool isValid = false;

            if (nameBox.Text != "" && nameBox.Text != null && typeBox.Text != ""
                && typeBox.Text != null && int.TryParse(ageBox.Text, out petAge) && petAge >= 0)
            {
                isValid = true;
            }

            return isValid;
        }

        public bool ExistsAlready()
        {
            bool found = false;
            int index = 0;
            //this makes sure the pet isn't a repeat
            while (!found && index < pets.Count)
            {
                if (pets[index].Name == nameBox.Text && pets[index].Type == typeBox.Text
                        && pets[index].Age == petAge)
                {
                    found = true;
                }

                index++;
            }

            return found;
        }
        public void Clear()
        {
            nameBox.Clear();
            typeBox.Clear();
            ageBox.Clear();
        }


        private void petPopulateButton_Click(object sender, RoutedEventArgs e)
        {
            //populates the listbox
            if (ValidInput())
            {
                Pet newPet = new Pet(nameBox.Text, typeBox.Text, petAge);

                if (petsListbox.Items.Count == 0)
                {
                    petsListbox.Items.Add("Pets Name: " + newPet.Name);
                    petsListbox.Items.Add("Type of Pet: " + newPet.Type);
                    petsListbox.Items.Add("Pets Age: " + newPet.Age);
                    pets.Add(newPet);
                    Clear();
                    nameBox.Focus();
                }
                else
                {
                    if (!ExistsAlready())
                    {
                        petsListbox.Items.Add("Pets Name: " + newPet.Name);
                        petsListbox.Items.Add("Type of Pet: " + newPet.Type);
                        petsListbox.Items.Add("Pets Age: " + newPet.Age);
                        pets.Add(newPet);
                        Clear();
                        nameBox.Focus();
                    }
                    else
                    {
                        MessageBox.Show(newPet.Name + " the " + newPet.Type + " already exists.");
                        Clear();
                        nameBox.Focus();
                    }
                    }
                }
                else
                {
                    MessageBox.Show("Invalid input.");
                    Clear();
                    nameBox.Focus();
                }
            }
        }
    }

