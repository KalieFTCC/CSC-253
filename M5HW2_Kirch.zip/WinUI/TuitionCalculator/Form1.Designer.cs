﻿namespace TuitionCalculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.yearlyTuitionList = new System.Windows.Forms.ListBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // yearlyTuitionList
            // 
            this.yearlyTuitionList.FormattingEnabled = true;
            this.yearlyTuitionList.Location = new System.Drawing.Point(12, 60);
            this.yearlyTuitionList.Name = "yearlyTuitionList";
            this.yearlyTuitionList.Size = new System.Drawing.Size(258, 95);
            this.yearlyTuitionList.TabIndex = 0;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(72, 12);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(130, 23);
            this.calcButton.TabIndex = 1;
            this.calcButton.Text = "Tuition Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 167);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.yearlyTuitionList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox yearlyTuitionList;
        private System.Windows.Forms.Button calcButton;
    }
}

