﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tuition_Library
{
    public class Calculations
    {
        public static List<String> projectedTuition(int starting, double percentincrease, int year)
        {
            List<String> result = new List<String>();
            double tuitionImplent = starting;
            for (int i = 1; i <= year; i++) 
            {
                tuitionImplent += tuitionImplent * percentincrease;
                result.Add(tuitionImplent.ToString("C"));
            }
            return result;
        }
    }
}
