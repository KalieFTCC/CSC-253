﻿using Analysis_Library;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
* 10/22/2022
* CSC 253
* Kalie Kirch
* This is the first assignment for this week, Unique words, It is just the first part of the bigger Text File Analysis program, but it takes a file and turns that file into 
* a list with all the unique words and displays them.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void uniqueButton_Click(object sender, EventArgs e)
        {
            List<string> wordList = LinQOperations.AccessFile();
            List <string> displayList = LinQOperations.UniqueWords(wordList);
            foreach (string word in displayList) 
            {
                namesListBox.Items.Add(word);
            }
        }
    }
}
