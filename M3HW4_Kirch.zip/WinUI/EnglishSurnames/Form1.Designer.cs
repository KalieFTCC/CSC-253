﻿namespace EnglishSurnames
{
    partial class SurnamesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.surnamesList = new System.Windows.Forms.ListBox();
            this.LongerThanButton = new System.Windows.Forms.Button();
            this.ShorterThanButton = new System.Windows.Forms.Button();
            this.startsWithButton = new System.Windows.Forms.Button();
            this.longerTxtbox = new System.Windows.Forms.TextBox();
            this.shorterthanTextbox = new System.Windows.Forms.TextBox();
            this.beginsTxtbox = new System.Windows.Forms.TextBox();
            this.findNameButton = new System.Windows.Forms.Button();
            this.searchTxtbox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // surnamesList
            // 
            this.surnamesList.FormattingEnabled = true;
            this.surnamesList.Location = new System.Drawing.Point(108, 223);
            this.surnamesList.Name = "surnamesList";
            this.surnamesList.Size = new System.Drawing.Size(418, 381);
            this.surnamesList.TabIndex = 0;
            // 
            // LongerThanButton
            // 
            this.LongerThanButton.Location = new System.Drawing.Point(81, 29);
            this.LongerThanButton.Name = "LongerThanButton";
            this.LongerThanButton.Size = new System.Drawing.Size(205, 23);
            this.LongerThanButton.TabIndex = 1;
            this.LongerThanButton.Text = "Find Names Longer Than";
            this.LongerThanButton.UseVisualStyleBackColor = true;
            this.LongerThanButton.Click += new System.EventHandler(this.LongerThanButton_Click);
            // 
            // ShorterThanButton
            // 
            this.ShorterThanButton.Location = new System.Drawing.Point(81, 78);
            this.ShorterThanButton.Name = "ShorterThanButton";
            this.ShorterThanButton.Size = new System.Drawing.Size(205, 23);
            this.ShorterThanButton.TabIndex = 2;
            this.ShorterThanButton.Text = "Find all names Shorter than";
            this.ShorterThanButton.UseVisualStyleBackColor = true;
            this.ShorterThanButton.Click += new System.EventHandler(this.ShorterThanButton_Click);
            // 
            // startsWithButton
            // 
            this.startsWithButton.Location = new System.Drawing.Point(81, 127);
            this.startsWithButton.Name = "startsWithButton";
            this.startsWithButton.Size = new System.Drawing.Size(205, 23);
            this.startsWithButton.TabIndex = 3;
            this.startsWithButton.Text = "Find all Names that Start with";
            this.startsWithButton.UseVisualStyleBackColor = true;
            this.startsWithButton.Click += new System.EventHandler(this.startsWithButton_Click);
            // 
            // longerTxtbox
            // 
            this.longerTxtbox.Location = new System.Drawing.Point(389, 32);
            this.longerTxtbox.Name = "longerTxtbox";
            this.longerTxtbox.Size = new System.Drawing.Size(164, 20);
            this.longerTxtbox.TabIndex = 4;
            // 
            // shorterthanTextbox
            // 
            this.shorterthanTextbox.Location = new System.Drawing.Point(389, 81);
            this.shorterthanTextbox.Name = "shorterthanTextbox";
            this.shorterthanTextbox.Size = new System.Drawing.Size(164, 20);
            this.shorterthanTextbox.TabIndex = 5;
            // 
            // beginsTxtbox
            // 
            this.beginsTxtbox.Location = new System.Drawing.Point(389, 127);
            this.beginsTxtbox.Name = "beginsTxtbox";
            this.beginsTxtbox.Size = new System.Drawing.Size(164, 20);
            this.beginsTxtbox.TabIndex = 6;
            // 
            // findNameButton
            // 
            this.findNameButton.Location = new System.Drawing.Point(81, 171);
            this.findNameButton.Name = "findNameButton";
            this.findNameButton.Size = new System.Drawing.Size(205, 23);
            this.findNameButton.TabIndex = 7;
            this.findNameButton.Text = "Find Name";
            this.findNameButton.UseVisualStyleBackColor = true;
            this.findNameButton.Click += new System.EventHandler(this.findNameButton_Click);
            // 
            // searchTxtbox
            // 
            this.searchTxtbox.Location = new System.Drawing.Point(389, 171);
            this.searchTxtbox.Name = "searchTxtbox";
            this.searchTxtbox.Size = new System.Drawing.Size(164, 20);
            this.searchTxtbox.TabIndex = 8;
            // 
            // SurnamesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(609, 640);
            this.Controls.Add(this.searchTxtbox);
            this.Controls.Add(this.findNameButton);
            this.Controls.Add(this.beginsTxtbox);
            this.Controls.Add(this.shorterthanTextbox);
            this.Controls.Add(this.longerTxtbox);
            this.Controls.Add(this.startsWithButton);
            this.Controls.Add(this.ShorterThanButton);
            this.Controls.Add(this.LongerThanButton);
            this.Controls.Add(this.surnamesList);
            this.Name = "SurnamesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "English Surnames";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox surnamesList;
        private System.Windows.Forms.Button LongerThanButton;
        private System.Windows.Forms.Button ShorterThanButton;
        private System.Windows.Forms.Button startsWithButton;
        private System.Windows.Forms.TextBox longerTxtbox;
        private System.Windows.Forms.TextBox shorterthanTextbox;
        private System.Windows.Forms.TextBox beginsTxtbox;
        private System.Windows.Forms.Button findNameButton;
        private System.Windows.Forms.TextBox searchTxtbox;
    }
}

