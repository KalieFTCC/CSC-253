﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/**
* 10/8/2022
* CSC 253
* Kalie Kirch
* Searches through an extensive list of english surnames
*/


namespace EnglishSurnames
{
    public partial class SurnamesForm : Form
    {
        /* declare string sname of max length 14674, as file can store 14674 surnames */
        string[] sname = new string[14674];
        int i = 0;
        public SurnamesForm()
        {
            InitializeComponent();
            //On start, this has the user input the text file. This is to avoid having it not work when sending the file over, as root folders change depending on the computer you run in.
            using (OpenFileDialog openFileDialog = new OpenFileDialog() { Filter = "Text Documents(*.txt)|*.txt", ValidateNames = true, Multiselect = false })
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string[] lines = System.IO.File.ReadAllLines(openFileDialog.FileName);
                    List<string> surnames = new List<string>();
                    //for each loop populates the list.
                    foreach (string surname in lines)
                    {
                        this.surnamesList.Items.Add(surname);
                        sname[i] = surname;
                        i = i + 1;
                    }
                }
            }
        }
        private void LongerThanButton_Click(object sender, EventArgs e)
        {
            int n, j;
            /* take the integer value in variable n */
            n = Convert.ToInt32(longerTxtbox.Text);
            surnamesList.Items.Clear();
            for (j = 0; j < i; j++)
            {
                /* if length of each surname length is greater than n */
                if (sname[j].Length > n)
                {
                    /* print surnames in listbox */
                    surnamesList.Items.Add(sname[j]);
                }
            }

        }

        private void ShorterThanButton_Click(object sender, EventArgs e)
        {
            int n, j;
            /* take the integer value in variable n */
            n = Convert.ToInt32(shorterthanTextbox.Text);
            surnamesList.Items.Clear();
            for (j = 0; j < i; j++)
            {
                /* if length of each surname length is less than n */
                if (sname[j].Length < n)
                {
                    /* print surnames in listbox */
                    surnamesList.Items.Add(sname[j]);
                }
            }
        }

        private void startsWithButton_Click(object sender, EventArgs e)
        {
            int j;
            string n;
            /* console input of first n characters */
            n = beginsTxtbox.Text;
            surnamesList.Items.Clear();
            for (j = 0; j < i; j++)
            {
                /* if fisrt three letters is n */
                if (sname[j].Substring(0, 3) == n)
                {
                    surnamesList.Items.Add(sname[j]);
                }
            }
        }

        private void findNameButton_Click(object sender, EventArgs e)
        {
            int j, l = 0;
            string n;
            /* n names the surname */
            n = searchTxtbox.Text;
            surnamesList.Items.Clear();
            for (j = 0; j < i; j++)
            {
                /* if surname matches */
                if (sname[j] == n)
                {
                    MessageBox.Show("The surname " + n + " is on the list");
                }
                /* if it does not match */
                else
                {
                    l = l + 1;
                }
            }
            /* if no match found */
            if (l == i)
            {
                MessageBox.Show("No such surname of " + n + " is here");
            }
        }
    }
}
